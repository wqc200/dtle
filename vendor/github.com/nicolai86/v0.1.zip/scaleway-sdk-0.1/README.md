# Scaleway SDK

A fork of the scaleway cli repository which only aims at being an API SDK - nothing more.

## Tests

```bash
$ go test ./...
```